# Kalaka South Mining – Starter

This is a starter Vite + React + Tailwind CSS project for the Kalaka South Mining website.

## Scripts

- `npm install` – install dependencies
- `npm run dev` – start local dev server
- `npm run build` – build for production
- `npm run preview` – preview the production build

The app is currently a single-page layout with placeholder sections.
Claude will extend the sections based on the approved UX plan.

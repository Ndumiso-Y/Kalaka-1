import React from 'react';
import HeroSection from './sections/HeroSection.jsx';
import AboutSection from './sections/AboutSection.jsx';
import FertilizerPortfolioSection from './sections/FertilizerPortfolioSection.jsx';
import SupplyChainSection from './sections/SupplyChainSection.jsx';
import ValueAddSection from './sections/ValueAddSection.jsx';
import LeadershipSection from './sections/LeadershipSection.jsx';
import ContactSection from './sections/ContactSection.jsx';
import Footer from './sections/Footer.jsx';
import Logo from './assets/images/Logo.png';

const navItems = [
  { href: '#home', label: 'Home' },
  { href: '#about', label: 'About' },
  { href: '#fertilizers', label: 'Fertilizers' },
  { href: '#supply-chain', label: 'Supply Chain' },
  { href: '#value-add', label: 'Value Add' },
  { href: '#leadership', label: 'Leadership' },
  { href: '#contact', label: 'Contact' },
];

function App() {
  return (
    <div className="min-h-screen bg-kalakaPurple text-slate-100">
      <header className="sticky top-0 z-20 border-b border-slate-800 bg-kalakaPurple/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <a href="#home" className="flex items-center gap-2">
            {Logo && (
              <img
                src={Logo}
                alt="Kalaka South Mining logo"
                className="h-8 w-auto"
              />
            )}
            <span className="text-sm font-semibold uppercase tracking-[0.2em]">
              Kalaka South Mining
            </span>
          </a>
          <nav className="hidden gap-6 text-sm md:flex">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-slate-200 transition hover:text-kalakaGold"
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main>
        <HeroSection />
        <AboutSection />
        <FertilizerPortfolioSection />
        <SupplyChainSection />
        <ValueAddSection />
        <LeadershipSection />
        <ContactSection />
      </main>

      <Footer />
    </div>
  );
}

export default App;

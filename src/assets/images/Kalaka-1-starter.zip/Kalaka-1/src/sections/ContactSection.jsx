import React from 'react';

function ContactSection() {
  return (
    <section
      id="contact"
      className="border-b border-slate-800 bg-kalakaPurple px-4 py-16"
    >
      <div className="mx-auto max-w-6xl">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-kalakaGold">
          Kalaka South Mining
        </p>
        <h2 className="mt-3 text-2xl font-semibold sm:text-3xl">
          Contact / RFQ section placeholder
        </h2>
        <p className="mt-4 max-w-2xl text-sm text-slate-300">
          This is a placeholder section. Content and layout will be refined by Claude
          based on the approved UX plan for the Kalaka South Mining website.
        </p>
      </div>
    </section>
  );
}

export default ContactSection;

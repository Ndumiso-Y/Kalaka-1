import React from 'react';

function Footer() {
  return (
    <footer className="border-t border-slate-800 bg-kalakaPurple px-4 py-8 text-sm text-slate-400">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 md:flex-row">
        <p>© {new Date().getFullYear()} Kalaka South Mining SA (Pty) Ltd. All rights reserved.</p>
        <p className="text-xs uppercase tracking-[0.25em] text-slate-500">
          Your Trading Partner
        </p>
      </div>
    </footer>
  );
}

export default Footer;
